package com.brickbreaker;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

public class Music {
    MediaPlayer mediaPlayer;
    public Music(){
        /*موسیقی زمان اجرا بازی را مشخص می کند*/
        Media music = new Media("file:/E://University/Code//BrickBreaker/beauty.mp3");
        mediaPlayer = new MediaPlayer(music);
        mediaPlayer.play();
        mediaPlayer.setAutoPlay(true);
    }
}
