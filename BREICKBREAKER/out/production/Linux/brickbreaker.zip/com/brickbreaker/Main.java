package com.brickbreaker;

import com.sun.xml.internal.bind.v2.runtime.reflect.opt.Const;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import sun.misc.FloatConsts;

public class Main extends Application {

    static Scene scene;
    private Object Stage;
   // private Music mainMusic;

    private Pane pane = new Pane();
    private Pane pane1 = new Pane();
    private  Pane pane2 = new Pane();
    private Pane pane3 = new Pane();
    @Override
    public void start(javafx.stage.Stage primaryStage) {

        /*در این قسمت  سازنده کلاس موسیقی برای  منو اصلی را صدا می رنیم*/
        Music menuMusic = new Music();

        String design= " -fx-background-color:" + "#c3c4c4," + "linear-gradient(#d6d6d6 50%, white 100%)," + "radial-gradient(center 50% -40%, radius 200%, #e6e6e6 45%, rgba(230,230,230,0) 50%);" +
                "-fx-background-radius: 30;" + "-fx-background-insets: 0,1,1;" + "-fx-text-fill: black;" + "-fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 3, 0.0 , 0 , 1 );";
        /*دکمه های منو را تعریف می کنیم و علاوه بر آن استایل آن را مشخص می کنیم */
        Button start = new Button("NEW GAME");
        start.setStyle(design);
        Button exit = new Button("QUIT");
        exit.setStyle(design);
        Button option = new Button("OPTION");
        option.setStyle(design);
        Button easy = new Button("EASY");
        easy.setStyle(design);
        Button medium = new Button("MEDIUM");
        medium.setStyle(design);
        Button hard = new Button("HARD");
        hard.setStyle(design);

        /* در منوی شروع گطینه option را برای تعیین سختی بازی در نظر می گیریم*/
        start.setOnMouseClicked(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                gamePlay easyOption = new gamePlay(Stage, primaryStage);
            }
        });
        /*در این قسمت گزینه خروج از بازی در نظر گرفته می شود*/
        exit.setOnMouseClicked(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                System.exit(0);
            }
        });

        option.setOnMouseClicked(new EventHandler<MouseEvent>() {
            // در این قسمت برای گزینه option  نوع سختی بازی را مشخص می کنیم در سه سطح اسان متوسط و سخت
            public void handle(MouseEvent event) {
                easy.setOnMouseClicked(new EventHandler<MouseEvent>() {
                    public void handle(MouseEvent event) {
                        //mainMusic = new Music();
                        FixedValue.BALL_INCREASE_SPEED_INCREMENT = 0;
                        gamePlay easyGamePlay = new gamePlay(Stage, primaryStage);
                    }
                });

                medium.setOnMouseClicked(new EventHandler<MouseEvent>() {
                    public void handle(MouseEvent event) {
                        //mainMusic = new Music();
                        FixedValue.BALL_INCREASE_SPEED_INCREMENT = 0.001;
                        gamePlay mediumGamePlay = new gamePlay(Stage, primaryStage);
                    }
                });

                hard.setOnMouseClicked(new EventHandler<MouseEvent>() {
                    public void handle(MouseEvent event) {
                        //mainMusic = new Music();
                        FixedValue.BALL_INCREASE_SPEED_INCREMENT = 0.002;
                        gamePlay hardGamePlay = new gamePlay(Stage, primaryStage);

                    }
                });

                easy.setLayoutX(90);
                easy.setLayoutY(300);
                medium.setLayoutX(130);
                medium.setLayoutY(340);
                hard.setLayoutX(200);
                hard.setLayoutY(380);

                BackgroundImage myBI = new BackgroundImage(new Image("file:E:/Linux/src/com/brickbreaker.jpg"),
                        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
                pane2.setBackground(new Background(myBI));

                scene = new Scene(pane2, FixedValue.SCREEN_WIDTH, FixedValue.SCREEN_HEIGHT);

                primaryStage.setScene(scene);
                primaryStage.setTitle("Difficalty");
                primaryStage.setResizable(false);
                primaryStage.sizeToScene();
                primaryStage.show();
            }
        });

        /*دکمه ها به صفحه منو اضافه می شوند*/
        pane.getChildren().add(start);
        pane.getChildren().add(exit);
        pane.getChildren().add(option);
        pane2.getChildren().add(easy);
        pane2.getChildren().add(medium);
        pane2.getChildren().add(hard);

        start.setLayoutX(80);
        start.setLayoutY(290);
        option.setLayoutX(150);
        option.setLayoutY(330);
        exit.setLayoutX(210);
        exit.setLayoutY(370);

        BackgroundImage myBI = new BackgroundImage(new Image("file:E:/Linux/src/com/brickbreaker.jpg"),
                BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        pane.setBackground(new Background(myBI));

        scene = new Scene(pane, FixedValue.SCREEN_WIDTH, FixedValue.SCREEN_HEIGHT);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Menu");
        primaryStage.setResizable(false);
        primaryStage.sizeToScene();
        primaryStage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }
}


