package com.brickbreaker;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.binding.Bindings;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.text.Text;
import javafx.scene.paint.Color;
import javafx.scene.Scene;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;

public class gamePlay {
    Scene scene;

    private Ball mainBall;
    private Wall mainWall;
    private List<List<Brick>> brickList = new ArrayList();
    private Paddle mainPaddle;
    private Group mainGroup;
    private Object primaryStage;
    private Stage stage;
    private IntegerProperty score = new SimpleIntegerProperty(0);
    public static boolean isGameOver = false, isWin = false;

    Timeline mainTimeline;
    Text txtScore, txtTime;
    public static int k, lives = FixedValue.STARTING_LIVES, totalScore, damagedBrick;
    public static long passedSec, currentSec, secondsPassed;
    List<Circle> livesIconList = new ArrayList();
    Timer myTimer = new Timer();
    Label[] damage = new Label[FixedValue.BRICKS_PER_ROW * FixedValue.BRICKS_PER_COLUMN];
    int[] damageBrick = new int[FixedValue.BRICKS_PER_COLUMN * FixedValue.BRICKS_PER_ROW];
    int[] m = new int[FixedValue.BRICKS_PER_COLUMN * FixedValue.BRICKS_PER_ROW];
    int t =  0, w = 0;
    public gamePlay(Object stage, Stage primaryStage)  {
        /*متغییری به نام mainGroup  تعریف می کینم که عملکرد آن به مانند pane  می باشد و تنها قصد اضافه کردن عوامل  بازی استفاده می شود*/
        mainGroup = new Group();
         /*حاشیه بازی نواری قهوه ای  رنگ را شامل می شود در این قسمت برای ساختن این حاشیه تلاش می شود
         این قسمت از 4 مستطیل تشکیل شده است که برای اضافه کردن آن به صفحه اصلی بازی صدا زده می شوند*/
        mainWall = new Wall(FixedValue.WALL_COLOR);
        for (Rectangle boundary : mainWall.getShapeList()) {
            mainGroup.getChildren().add(boundary);
        }
        /*مستطیل های آجر بازی را در این قسمت می سازیم
         * تنها استفاده از کلاس brick ان است که مستطیل ها را انجا صدا زده مختصات مورد نطر به انها داده می شود و
         *  در کلاس  newGamePlay به ارایه ای هز جنس list  اضافه می شودو ان اریه به صفحه اصلی بازی اضافه می شود*/
        for (int i = 0; i < FixedValue.BRICKS_PER_ROW; i++) {
            brickList.add(new ArrayList());
            for (int j = 0; j < FixedValue.BRICKS_PER_COLUMN; j++) {
                double xOffset = FixedValue.WALL_WIDTH + FixedValue.BRICKS_HORIZONTAL_SPACING + i * (FixedValue.BRICKS_WIDTH + FixedValue.BRICKS_HORIZONTAL_SPACING);
                double yOffset = FixedValue.WALL_WIDTH + FixedValue.BRICKS_VERTICAL_SPACING + j * (FixedValue.BRICKS_HEIGHT + FixedValue.BRICKS_VERTICAL_SPACING);
                Brick brickToAdd = new Brick(xOffset, yOffset, t, w);
                damage[5 * i + j] = new Label();
                damage[5 * i + j].setTextFill(Color.WHITESMOKE);
                damageBrick[5 * i + j] = FixedValue.hit;
                damage[5 * i + j].setText("" + damageBrick[5 * i + j]);
                damage[5 * i + j].setLayoutX(Brick.centerX - 5);
                damage[5 * i + j].setLayoutY(Brick.centerY - 10);
                brickList.get(i).add(brickToAdd);
                m[5 * i + j] = w + t;
                w++;
                mainGroup.getChildren().addAll(brickToAdd.getShape(),damage[5 * i + j]);
            }
            t++;
        }
        /*سازنده کلاس paddle را صدا می زنیم و بعد object های ساخته شده در سازنده را به صفحه اصلی اضافه می کند*/
        mainPaddle = new Paddle();
        mainGroup.getChildren().add(mainPaddle.getShape());
        /*سازنهده مربوط به کلاس توپ را صدا می زنیم تا شی مزبوط به توپ را بسازد و ان را به صفحه اصلی بازی اضافه کند*/
        mainBall = new Ball(FixedValue.BALL_STARTX, FixedValue.BALL_STARTY);
        mainGroup.getChildren().add(mainBall.getShape());

        mainGroup.setFocusTraversable(true);
        mainGroup.requestFocus();
        /*این قسمت برای تعیین جهت حرکت توپ پس از برخورد با اجر ها و paddle و حاشیه بازی است*/
        currentSec = System.currentTimeMillis();
        mainTimeline = new Timeline(new KeyFrame(new Duration(10.0), t -> {
            // برخورد با paddle
            if (mainBall.getShape().intersects(mainPaddle.getShape().getBoundsInParent()) && mainBall.isMovingDown()) {
                mainBall.collideWithPaddle(mainPaddle);
                mainBall.changeYDirection();
            }
            //حاشیه بازی برخورد با چپ
            if (mainBall.getShape().intersects(mainWall.getLeftRectangle().getBoundsInLocal()) && !mainBall.isMovingRight()) {
                mainBall.changeXDirection();
            }
            //حاشیه بازی برخورد با راست
            if (mainBall.getShape().intersects(mainWall.getRightRectangle().getBoundsInLocal()) && mainBall.isMovingRight()) {
                mainBall.changeXDirection();
            }
            //حاشیه بازی برخورد با بالا
            if (mainBall.getShape().intersects(mainWall.getTopRectangle().getBoundsInLocal()) && !mainBall.isMovingDown()) {
                mainBall.changeYDirection();
            }
            //حاشیه بازی  برخورد با پایین
            if (mainBall.getShape().intersects(mainWall.getLowerBoundary().getBoundsInLocal())) {
                decreaseLife(primaryStage);
            }
            //
            if (mainBall.hasUpdated()) {
                crash();
                mainBall.changeUpdate();
            }
        }));
        mainTimeline.setCycleCount(Timeline.INDEFINITE);
        mainTimeline.playFromStart();

        /*امتیاز بازی را نشان می دهد*/
        txtScore = new Text(10, -20, "Score");
        txtScore.textProperty().bind(Bindings.format("Score: %1$d", score));
        txtScore.setFill(Color.LIGHTPINK);
        txtScore.setStyle("-fx-font: 22 arial;");
        mainGroup.getChildren().add(txtScore);
        mainGroup.setLayoutY(FixedValue.SCORE_HEIGHT);

        txtScore = new Text(320, -20, "Ball");
        txtScore.textProperty().bind(Bindings.format("Ball: "));
        txtScore.setFill(Color.LIGHTPINK);
        txtScore.setStyle("-fx-font: 22 arial;");
        mainGroup.getChildren().add(txtScore);
        mainGroup.setLayoutY(FixedValue.SCORE_HEIGHT);
        /*توپ های اضافی را به صفحه بازی اضافه می کند*/
        for (int i = 0; i < lives; i++) {
            Circle newLife = new Circle(FixedValue.SCREEN_WIDTH - 30 * i - 30, -25, FixedValue.BALL_SIZE, FixedValue.BALL_COLOR);
            mainGroup.getChildren().add(newLife);
            livesIconList.add(newLife);
        }

        scene = new Scene(mainGroup, FixedValue.SCREEN_WIDTH, FixedValue.SCREEN_HEIGHT + FixedValue.SCORE_HEIGHT);
        scene.setFill(FixedValue.SCREEN_COLOR);

        primaryStage.setScene(scene);
        primaryStage.setTitle("BrickBreaker");
        primaryStage.setResizable(false);
        primaryStage.sizeToScene();
        primaryStage.show();
    }
    /*در این قسمت برای برخورد ها و حذف شدن اجر ها کسب امتیاز و ... تدابیری اندیشیده می شود
     * خیلی از متود های به کار رفته در این در ملاس توپ تعریف می شود*/
    public void crash() {
        for (int i = 0; i < brickList.size(); i++) {
            for (int j = 0; j < brickList.get(i).size(); j++) {
                Brick brick = brickList.get(i).get(j);
                if (mainBall.getShape().intersects(brick.getShape().getBoundsInLocal())) {
                    System.out.println("i: " + i + " && j: " + j);
                    if(damageBrick[5 * i + j] == 0) {
                        mainBall.collideWithBrick(brick);
                        brickList.get(i).remove(brick);
                        mainGroup.getChildren().removeAll(brick.getShape(), damage[5 * i + j]);
                        if (m[5 * i + j] % 4 == 1){
                            Bonus.Gift(k % 3);
                            k++;
                        }
                        if (Bonus.isGift_1) {
                            score.set(score.get() + 2);
                            totalScore += 2;
                        } else {
                            score.set(score.get() + 1);
                            totalScore++;
                        }
                        damagedBrick++;
                        if (damagedBrick == (FixedValue.BRICKS_PER_COLUMN) * (FixedValue.BRICKS_PER_ROW)){
                            isWin = true;
                            EndView winView = new EndView(stage, (Stage) primaryStage);
                        }
                    }else{
                        damageBrick[5 * i + j]--;
                        damage[5 * i + j].setText("" + damageBrick[5 * i + j]);
                    }
                }
            }
        }
    }
    /*کم شدن توپ ها از بازی*/
    public void decreaseLife(Object primaryStage) {
        lives -= 1;
        if (lives <= -1) {
            passedSec = System.currentTimeMillis();
            isGameOver = true;
            if (isGameOver) {
                EndView gameoverView = new EndView(stage, (Stage) primaryStage);
            }
        }
        if(isGameOver == false || isWin == false) {
            mainGroup.getChildren().remove(livesIconList.get(lives));
            livesIconList.remove(lives);
            mainGroup.getChildren().remove(mainBall.getShape());
            mainBall = new Ball(FixedValue.BALL_STARTX, FixedValue.BALL_STARTY);
            mainGroup.getChildren().add(mainBall.getShape());
        }
    }

    public static long Time(){
        long time;
        time = passedSec - currentSec;
        return  time;
    }
   /* *//*در صورت پیروزی اجرا میشود*//*
    public void youWin (Object primaryStage) {
        isWin = true;
        if(isWin == true){
            EndView winView = new EndView(stage, (Stage) primaryStage);
        }
    }*/
}


