package com.brickbreaker;

import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.Timer;
import java.util.TimerTask;

public class EndView {
    /*صفحه اخر بازی را در صورت پیروزی و شکست اجرا میکند*/
    private Scene endView;
    private Pane pane = new Pane();
    private long minute, second;

    public EndView(Object stage, Stage primaryStage) {
        Pane pane = new Pane();
        String design= " -fx-background-color:" + "#c3c4c4," + "linear-gradient(#d6d6d6 50%, white 100%)," + "radial-gradient(center 50% -40%, radius 200%, #e6e6e6 45%, rgba(230,230,230,0) 50%);" +
                "-fx-background-radius: 30;" + "-fx-background-insets: 0,1,1;" + "-fx-text-fill: black;" + "-fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 3, 0.0 , 0 , 1 );";
        /*دکمه را تعریف می کنیم و علاوه بر آن استایل آن را مشخص می کنیم */
        Button restart = new Button("RESTART");
        restart.setStyle(design);
        Timer myTimer = new Timer();

        second = gamePlay.Time() / 1000;
        minute =  second / 60;
        second = second - minute * 60;

        if (gamePlay.isGameOver == true) {
            Label score = new Label("Score: " + gamePlay.totalScore);
            score.setTextFill(Color.WHITESMOKE);
            Label time = new Label();
            if(minute < 10 && second < 10) {
                time.setText("Time: 0" + minute + " : 0" + second);
            }
            else {
                time.setText("Time: 0" + minute + " : " + second);
            }
            time.setTextFill(Color.WHITESMOKE);
            pane.getChildren().addAll(score, time);
            score.setStyle("-fx-font: 24 arial");
            time.setStyle("-fx-font: 18 arial");
            score.setLayoutX(200);
            score.setLayoutY(350);
            time.setLayoutX(200);
            time.setLayoutY(390);
            BackgroundImage myBI = new BackgroundImage(new Image("file:E:/Linux/src/com/gameOver.jpg"),
                    BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
            pane.setBackground(new Background(myBI));
            restart.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent event) {
                    gamePlay restart = new gamePlay(stage, primaryStage);
                }
            });
            pane.getChildren().add(restart);
        }
        if(gamePlay.isWin == true)
        {
            Label score = new Label("Score: " + gamePlay.totalScore);
            score.setTextFill(Color.WHITESMOKE);
            Label time = new Label("Time: " + minute + " : " + second);
            time.setTextFill(Color.WHITESMOKE);
            pane.getChildren().addAll(score, time);
            score.setStyle("-fx-font: 24 arial");
            time.setStyle("-fx-font: 18 arial");
            score.setLayoutX(200);
            score.setLayoutY(350);
            time.setLayoutX(200);
            time.setLayoutY(390);
            BackgroundImage myBI = new BackgroundImage(new Image("file:E:/Linux/src/com/youWin.jpg"),
                    BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
            pane.setBackground(new Background(myBI));
            restart.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent event) {
                    gamePlay restart = new gamePlay(stage, primaryStage);
                }
            });
            pane.getChildren().add(restart);
        }
        restart.setLayoutX(200);
        restart.setLayoutY(450);

        TimerTask task0 = new TimerTask() {
            @Override
            public void run() {
                int secondsPassed = 0;
                secondsPassed++;
                if(secondsPassed / 1000 >= 10) {
                    myTimer.cancel();
                    secondsPassed = 0;
                    System.exit(0);
                }
            }
        };
        endView = new Scene(pane, FixedValue.SCREEN_WIDTH, FixedValue.SCREEN_HEIGHT);

        primaryStage.setScene(endView);
        primaryStage.setTitle("Result");
        primaryStage.setResizable(false);
        primaryStage.sizeToScene();
        primaryStage.show();
    }
}
